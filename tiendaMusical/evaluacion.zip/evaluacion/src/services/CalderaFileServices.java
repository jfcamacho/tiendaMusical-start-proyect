/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

/**
 *
 * @author jeffersonfernandocamachomunoz
 */
public class CalderaFileServices {
    /**
     * 
     * @param args parámetros a ser almacenados en cada monitoreo
     * @return Retornar el estado de almacenamiento si se logró o no almacenar los datos
     */
    public boolean guardarDatos(String args[]){
        return true;
    }
}
