/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

/**
 *
 * @author jeffersonfernandocamachomunoz
 * Implementar el menú solicitado en el esquema general
 */
public class CalderaMenuServices {
    
    /**
     * 
     * @return Devolver la opción seleccionada del menú
     */
    public int menuCaldera(){
        return 0;
    }
}
